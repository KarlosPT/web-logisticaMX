document.write(`
<header class="header">
    <div class="header__inner">

        <!-- Brand -->
        <div class="header__brand">
            <div class="brand-wrap">

                <img src="./assets/img/escudo.png" alt="Escudo Ibero" class="brand-img stretched-link" width="100" height="40">

                <img src="./assets/img/ibero.png" alt="Logo Ibero" class="brand-title" width="100" height="40">

            </div>
        </div>
        <!-- End - Brand -->

        <div class="header__content">

            <!-- Content Header - Left Side: -->
            <div class="header__content-start">

                <!-- Navigation Toggler -->
                <button type="button" class="nav-toggler header__btn btn btn-icon btn-sm" aria-label="Nav Toggler">
                    <i class="psi-list-view"></i>
                </button>
                
            </div>
            <!-- End - Content Header - Left Side -->

            <!-- Content Header - Right Side: -->
            <div class="header__content-end">

                <!-- Notification Dropdown -->
                <div class="dropdown">

                    <!-- Toggler -->
                    <button class="header__btn btn btn-icon btn-sm" type="button" data-bs-toggle="dropdown" aria-label="Notification dropdown" aria-expanded="false">
                        <span class="d-block position-relative">
                            <i class="psi-bell"></i>
                            <span class="badge badge-super rounded bg-success p-1">

                                <span class="visually-hidden">No leídas</span>
                            </span>
                        </span>
                    </button>

                    <!-- Notification dropdown menu -->
                    <div class="dropdown-menu dropdown-menu-end w-md-300px">
                        <div class="border-bottom px-3 py-2 mb-3">
                            <h5>Alertas</h5>
                        </div>

                        <div class="list-group list-group-borderless">

                            <!-- List item -->
                            <div class="list-group-item list-group-item-action d-flex align-items-start mb-3">
                                <div class="flex-shrink-0 me-3">
                                    <i class="psi-repeat-2 text-green-300 fs-2"></i>
                                </div>
                                <div class="flex-grow-1 ">
                                    <a href="#" class="h6 d-block mb-0 stretched-link text-decoration-none">Vigencia</a>
                                    <small class="text-muted">Acreditación 202/1 vencerá en 15 días</small>
                                </div>
                            </div>

                            <!-- List item -->
                            <div class="list-group-item list-group-item-action d-flex align-items-start mb-3">
                                <div class="flex-shrink-0 me-3">
                                    <i class="psi-dollar-sign text-info fs-2"></i>
                                </div>
                                <div class="flex-grow-1 ">
                                    <a href="#" class="h6 d-block mb-0 stretched-link text-decoration-none">Presupuesto</a>
                                    <small class="text-muted">El presupuesto del proceso 203/4 está al 90%</small>
                                </div>
                            </div>

                            <!-- List item -->
                            <div class="list-group-item list-group-item-action d-flex align-items-start mb-3">
                                <div class="flex-shrink-0 me-3">
                                    <i class="psi-repeat-2 text-green-300 fs-2"></i>
                                </div>
                                <div class="flex-grow-1 ">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <a href="#" class="h6 mb-0 stretched-link text-decoration-none">Inicio de Proceso</a>
                                        <span class="badge bg-info rounded ms-auto">P304</span>
                                    </div>
                                    <small class="text-muted">El programa 304 debe iniciar un nuevo proceso</small>
                                </div>
                            </div>

                            <div class="text-center mb-2">
                                <a href="./alertas.html" class="btn-link">Mostrar todas las alertas</a>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- End - Notification dropdown -->

                <!-- User dropdown -->
                <div class="dropdown">

                    <!-- Toggler -->
                    <button class="header__btn btn btn-icon btn-sm" type="button" data-bs-toggle="dropdown" aria-label="User dropdown" aria-expanded="false">
                        <i class="psi-male"></i>
                    </button>

                    <!-- User dropdown menu -->
                    <div class="dropdown-menu dropdown-menu-end w-md-450px">

                        <!-- User dropdown header -->
                        <div class="d-flex align-items-center border-bottom px-3 py-2">
                            <div class="flex-shrink-0">
                                <img class="img-sm rounded-circle" src="./assets/img/profile-photos/1.png" alt="Profile Picture" loading="lazy">
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h5 class="mb-0">Nombre Usuario</h5>
                                <span class="text-muted fst-italic">usuario@ibero.mx</span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-7">

                                <!-- Simple widget and reports -->
                                <div class="list-group list-group-borderless mb-3">
                                    <div class="list-group-item text-center border-bottom mb-3">
                                        <p class="h1 display-1 text-green">17</p>
                                        <p class="h6 mb-0"><i class="pli-basket-coins fs-3 me-2"></i> Trámites </p>
                                        <small class="text-muted">Hay trámites por vencer</small>
                                    </div>
                                    <div class="list-group-item py-0 d-flex justify-content-between align-items-center">
                                        Presupuesto
                                        <small class="fw-bolder">$57,800</small>
                                    </div>
                                    <div class="list-group-item py-0 d-flex justify-content-between align-items-center">
                                        Ejercido
                                        <small class="fw-bolder text-danger">- $7,800</small>
                                    </div>
                                    <div class="list-group-item py-0 d-flex justify-content-between align-items-center">
                                        Remanente
                                        <span class="fw-bold text-success">$50,000</span>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-5">

                                <!-- User menu link -->
                                <div class="list-group list-group-borderless h-100 py-3">
                                    <a href="./alertas.html" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                        <span><i class="pli-mail fs-5 me-2"></i> Alertas</span>
                                        <span class="badge bg-danger rounded-pill">3</span>
                                    </a>
                                    <a href="./login.html" class="list-group-item list-group-item-action">
                                        <i class="pli-unlock fs-5 me-2"></i> Cerrar sesión
                                    </a>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
                <!-- End - User dropdown -->

            </div>
        </div>
    </div>
</header>
`);