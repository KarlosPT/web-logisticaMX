document.write(`

<!-- Fonts [ OPTIONAL ] -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="./assets/css/bootstrap.min.css">
<link rel="stylesheet" href="./assets/css/nifty.min.css">
<link rel="stylesheet" href="./assets/css/sac-settings.min.css">
<link rel="stylesheet" href="./assets/css/plicons.min.css">
<link rel="stylesheet" href="./assets/css/psicons.min.css">

<link rel="icon" type="image/x-icon" href="./assets/img/favicon.ico">

<style>
.modalfade {
    animation: fadeIn 0.5s;
    -moz-animation: fadeIn 0.5s; /* Firefox */
    -webkit-animation: fadeIn 0.5s; /* Safari and Chrome */
    -o-animation: fadeIn 0.5s; /* Opera */
}
@keyframes fadeIn {
    from {
        opacity:0;
    }
    to {
        opacity:1;
    }
}
@-moz-keyframes fadeIn { /* Firefox */
    from {
        opacity:0;
    }
    to {
        opacity:1;
    }
}
@-webkit-keyframes fadeIn { /* Safari and Chrome */
    from {
        opacity:0;
    }
    to {
        opacity:1;
    }
}
@-o-keyframes fadeIn { /* Opera */
    from {
        opacity:0;
    }
    to {
        opacity: 1;
    }
}
</style>

`);