document.write(`

    <div>

        <button class="btn btn-info dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            Seleccione Reporte
        </button>

        <ul class="dropdown-menu" style="">
            <li><a class="dropdown-item" href="./rep-tareas.html">Tareas</a></li>
            <li><a class="dropdown-item" href="./rep-programas.html">Situación de Programas</a></li>
            <li><a class="dropdown-item" href="./rep-pptoproc.html">Presupuesto por Proceso</a></li>
            <li><a class="dropdown-item" href="./rep-ppto-a.html">Presupuesto Anual</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="./grp-clasif.html">Gráfica Recomendaciones 1</a></li>
            <li><a class="dropdown-item" href="./grp-division.html">Gráfica Recomendaciones 2</a></li>

        </ul>

    </div>

`);