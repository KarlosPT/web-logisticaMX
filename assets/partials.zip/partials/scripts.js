document.write(`

<script src="./assets/vendors/popperjs/popper.min.js" defer></script>
<script src="./assets/vendors/bootstrap/bootstrap.min.js" defer></script>
<script src="./assets/js/nifty.js" defer></script>
<script src="./assets/vendors/chart.js/chart.min.js" defer></script>

`);

document.addEventListener( 'DOMContentLoaded', () => {

	if (document.getElementById("_dm-taskChart") === null) return;

    const taskChart = new Chart(
        document.getElementById("_dm-taskChart"), {
            type: "bar",
            data: {
                datasets: [
                    {
                        data: [
                            {kind: "Incidential", complete: 45},
                            {kind: "Coordinated", complete: 54},
                            {kind: "Planned", complete: 24},
                            {kind: "Other", complete: 34}
                        ],
                        barThickness: 7,
                        borderRadius: 3,
                        backgroundColor: "rgba(255,255,255, .7)",
                        parsing: {
                            yAxisKey: "kind",
                            xAxisKey: "complete"
                        }
                    }
                ]
            },
            options : {
                responsive: true,
                maintainAspectRatio: false,
                resizeDelay: 250,
                layout: {
                    padding: 0
                },
                indexAxis: 'y',
                plugins :{
                    legend: {
                        display: false
                    },
                    tooltip: {
                        caretSize: 0,
                        yAlign : "center",
                        callbacks: {
                            label: (context) => {
                                let label = context.dataset.label || "";
                                if (context.parsed.x !== null) label += " " + context.parsed.x + " Items Completed";
                                return label;
                            }
                        }
                    }
                },

                interaction: {
                    mode: "index",
                    intersect: true,
                },

                scales: {
                    y: {
                        display: false
                    },
                    x: {
                        display: false
                    }
                }
            }
        }
    );
});
