document.write(`
<nav id="mainnav-container" class="mainnav">
    <div class="mainnav__inner">

        <!-- Navigation menu -->
        <div class="mainnav__top-content scrollable-content pb-5">

            <!-- Profile Widget -->
            <div class="mainnav__profile mt-2 d-flex3">

                <div class="mt-2 d-mn-max"></div>

                <div class="mininav-content d-mn-max">
                    <div class="d-grid">

                        <!-- User name and position -->
                        
                        <span class="d-flex justify-content-center align-items-center">
                            <h6 class="mb-0">Nombre Usuario</h6>
                        </span>
                        <span class="d-flex justify-content-center align-items-center">
                            <small class="text-muted">Administrador</small>
                        </span>

                    </div>
                </div>

            </div>
            <!-- End - Profile widget -->

            <!-- Dashboard y reportes -->
            <div class="mainnav__category pt-2 pb-3">
                <ul id="mainnav" class="mainnav__menu nav flex-column">
                
                    <li class="nav-item">
                        <a href="./workspace.html" class="nav-link mininav-toggle py-1"><i class="pli-check-2 fs-5 me-2"></i>
                            <span class="nav-label mininav-content ms-1">Dashboard</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="./rep-tareas.html" class="nav-link mininav-toggle py-1"><i class="pli-bar-chart-3 fs-5 me-2"></i>
                            <span class="nav-label mininav-content ms-1">Reportes y Gráficas</span>
                        </a>
                    </li>

                </ul>
            </div>
            <!-- End - Dashboard y reportes -->

            <!-- Acreditación Category -->
            <div class="mainnav__category pt-2 pb-3">
                <h6 class="mainnav__caption mt-0 px-3 fw-bold">Acreditación</h6>
                <ul class="mainnav__menu nav flex-column">

                    <!-- Links -->
					
					<li class="nav-item">
						<a href="./procesos.html" class="nav-link mininav-toggle py-1"><i class="psi-repeat-2 fs-5 me-2"></i>
							<span class="nav-label mininav-content ms-1">Procesos</span>
						</a>
					</li>

					<li class="nav-item">
						<a href="./presupuestos.html" class="nav-link mininav-toggle py-1"><i class="pli-dollar-sign fs-5 me-2"></i>
							<span class="nav-label mininav-content ms-1">Presupuestos</span>
						</a>
					</li>

					<li class="nav-item">
						<a href="./tareas.html" class="nav-link mininav-toggle py-1"><i class="pli-pen-4 fs-5 me-2"></i>
							<span class="nav-label mininav-content ms-1">Tareas</span>
						</a>
					</li>

					<li class="nav-item">
						<a href="./tablero.html" class="nav-link mininav-toggle py-1"><i class="pli-split-four-windows fs-5 me-2"></i>
							<span class="nav-label mininav-content ms-1">Tablero</span>
						</a>
					</li>

                    <!-- END : Links -->

                </ul>
            </div>
            <!-- END : Acreditación Category -->

            <!-- Evaluación Category -->
            <div class="mainnav__category pt-2 pb-3">
                <h6 class="mainnav__caption mt-0 px-3 fw-bold">Evaluación</h6>
                <ul class="mainnav__menu nav flex-column">

                    <!-- Links -->
					
					<li class="nav-item">
						<a href="./categorias.html" class="nav-link mininav-toggle py-1"><i class="pli-books fs-5 me-2"></i>
							<span class="nav-label mininav-content ms-1">Categorías</span>
						</a>
					</li>

					<li class="nav-item">
						<a href="./clasificaciones.html" class="nav-link mininav-toggle py-1"><i class="pli-check fs-5 me-2"></i>
							<span class="nav-label mininav-content ms-1">Clasificaciones</span>
						</a>
					</li>

					<li class="nav-item">
						<a href="./recomendaciones.html" class="nav-link mininav-toggle py-1"><i class="pli-file-horizontal-text fs-5 me-2"></i>
							<span class="nav-label mininav-content ms-1">Recomendaciones</span>
						</a>
					</li>

                    <!-- END : Links -->

                </ul>
            </div>
            <!-- END : Evaluación Category -->

            <!-- Directorio Category -->
            <div class="mainnav__category pt-2 pb-3">
                <h6 class="mainnav__caption mt-0 px-3 fw-bold">Directorio</h6>
                <ul class="mainnav__menu nav flex-column">

                    <!-- Links -->
					
					<li class="nav-item">
                    <a href="./acreditadoras.html" class="nav-link mininav-toggle py-1"><i class="pli-building fs-5 me-2"></i>
                    <span class="nav-label mininav-content ms-1">Acreditadoras</span>
                    </a>
					</li>
                    
					<li class="nav-item">
						<a href="./programas.html" class="nav-link mininav-toggle py-1"><i class="pli-professor fs-5 me-2"></i>
							<span class="nav-label mininav-content ms-1">Programas</span>
						</a>
					</li>

                    <!-- END : Links -->

                </ul>
            </div>
            <!-- END : Directorio Category -->

            <!-- Administración Category -->
            <div class="mainnav__category pt-2 pb-3">
                <h6 class="mainnav__caption mt-0 px-3 fw-bold">Administración</h6>
                <ul class="mainnav__menu nav flex-column">

                    <!-- Links -->
					
					<li class="nav-item">
						<a href="./settings.html" class="nav-link mininav-toggle py-1"><i class="pli-gear fs-5 me-2"></i>
							<span class="nav-label mininav-content ms-1">Configuración</span>
						</a>
					</li>

					<li class="nav-item">
						<a href="./usuarios.html" class="nav-link mininav-toggle py-1"><i class="pli-male-female fs-5 me-2"></i>
							<span class="nav-label mininav-content ms-1">Usuarios</span>
						</a>
					</li>
                    
                    <!-- END : Links -->

                </ul>
            </div>
            <!-- END : Administración Category -->

        </div>
        <!-- End - Navigation menu -->

        <!-- Bottom navigation menu -->
        <div class="mainnav__bottom-content border-top pb-2">
            <ul id="mainnav" class="mainnav__menu nav flex-column">
			

				<li class="nav-item">
					<a href="./login.html" class="nav-link mininav-toggle py-1"><i class="pli-unlock fs-5 me-2"></i>
						<span class="nav-label mininav-content ms-1">Cerrar sesión</span>
					</a>
				</li>

            </ul>
        </div>
        <!-- End - Bottom navigation menu -->

    </div>
</nav>
`);