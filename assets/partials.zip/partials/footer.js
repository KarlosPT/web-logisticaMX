document.write(`
<footer class="content__boxed mt-auto">
<div class="content__wrap py-3 py-md-1 d-flex flex-column flex-md-row align-items-md-center">
    <div class="text-nowrap mb-4 mb-md-0">Copyright &copy; 2022 <a href="https://ibero.mx" class="ms-1 btn-link fw-bold text-danger">Universidad Ibero CDMX</a></div>
    <nav class="nav flex-column gap-1 flex-md-row gap-md-3 ms-md-auto" style="row-gap: 0 !important;">
        <a class="nav-link px-0" href="#">Recursos</a>
        <a class="nav-link px-0" href="#">Manual del Usuario</a>
        <a class="nav-link px-0" href="#">v0.2.0</a>
    </nav>
</div>
</footer>
`);